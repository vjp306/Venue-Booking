﻿namespace VenuBooking
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.book = new System.Windows.Forms.Button();
            this.name = new System.Windows.Forms.TextBox();
            this.cancel = new System.Windows.Forms.Button();
            this.addToWishList = new System.Windows.Forms.Button();
            this.bookAllSeats = new System.Windows.Forms.Button();
            this.CancelAllSeats = new System.Windows.Forms.Button();
            this.text = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Items.AddRange(new object[] {
            "A",
            "B",
            "C"});
            this.listBox1.Location = new System.Drawing.Point(490, 26);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(150, 104);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 20;
            this.listBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4"});
            this.listBox2.Location = new System.Drawing.Point(673, 26);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(150, 104);
            this.listBox2.TabIndex = 1;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // book
            // 
            this.book.Location = new System.Drawing.Point(490, 198);
            this.book.Name = "book";
            this.book.Size = new System.Drawing.Size(94, 29);
            this.book.TabIndex = 2;
            this.book.Text = "book";
            this.book.UseVisualStyleBackColor = true;
            this.book.Click += new System.EventHandler(this.book_Click);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(490, 165);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(333, 27);
            this.name.TabIndex = 3;
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(603, 198);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(94, 29);
            this.cancel.TabIndex = 4;
            this.cancel.Text = "cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // addToWishList
            // 
            this.addToWishList.Location = new System.Drawing.Point(716, 198);
            this.addToWishList.Name = "addToWishList";
            this.addToWishList.Size = new System.Drawing.Size(94, 29);
            this.addToWishList.TabIndex = 5;
            this.addToWishList.Text = "addToWaitList";
            this.addToWishList.UseVisualStyleBackColor = true;
            this.addToWishList.Click += new System.EventHandler(this.addToWishList_Click);
            // 
            // bookAllSeats
            // 
            this.bookAllSeats.Location = new System.Drawing.Point(490, 244);
            this.bookAllSeats.Name = "bookAllSeats";
            this.bookAllSeats.Size = new System.Drawing.Size(150, 29);
            this.bookAllSeats.TabIndex = 6;
            this.bookAllSeats.Text = "bookAllSeats";
            this.bookAllSeats.UseVisualStyleBackColor = true;
            this.bookAllSeats.Click += new System.EventHandler(this.bookAllSeats_Click);
            // 
            // CancelAllSeats
            // 
            this.CancelAllSeats.Location = new System.Drawing.Point(660, 244);
            this.CancelAllSeats.Name = "CancelAllSeats";
            this.CancelAllSeats.Size = new System.Drawing.Size(150, 29);
            this.CancelAllSeats.TabIndex = 7;
            this.CancelAllSeats.Text = "CancelAllSeats";
            this.CancelAllSeats.UseVisualStyleBackColor = true;
            this.CancelAllSeats.Click += new System.EventHandler(this.CancelAllSeats_Click);
            // 
            // text
            // 
            this.text.AutoSize = true;
            this.text.Location = new System.Drawing.Point(21, 416);
            this.text.Name = "text";
            this.text.Size = new System.Drawing.Size(0, 20);
            this.text.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(338, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 20);
            this.label3.TabIndex = 28;
            this.label3.Text = "no one in waitList";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(202, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "available seats:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 20);
            this.label1.TabIndex = 30;
            this.label1.Text = "Total Capacity:12 steats";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(317, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 20);
            this.label4.TabIndex = 31;
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 20;
            this.listBox3.Location = new System.Drawing.Point(872, 26);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(150, 104);
            this.listBox3.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(496, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 20);
            this.label5.TabIndex = 33;
            this.label5.Text = "Rows";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(674, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 20);
            this.label6.TabIndex = 34;
            this.label6.Text = "Colums";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(874, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 35;
            this.label7.Text = "wishlist Box";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(490, 142);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 20);
            this.label8.TabIndex = 36;
            this.label8.Text = "Name:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1095, 450);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.listBox3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.text);
            this.Controls.Add(this.CancelAllSeats);
            this.Controls.Add(this.bookAllSeats);
            this.Controls.Add(this.addToWishList);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.name);
            this.Controls.Add(this.book);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "VenuBooking";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListBox listBox1;
        private ListBox listBox2;
        private Button book;
        private TextBox name;
        private Button cancel;
        private Button addToWishList;
        private Button bookAllSeats;
        private Button CancelAllSeats;
        private Label text;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label4;
        private ListBox listBox3;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
    }
}