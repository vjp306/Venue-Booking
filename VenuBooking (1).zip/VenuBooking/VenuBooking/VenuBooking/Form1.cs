using NPoco.Expressions;
using System.ComponentModel;
using System.Windows.Forms;

namespace VenuBooking
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string sr;
        string selectedcol;

        //creating the seats class object for calling all the methods
        Seats s = new Seats();
        private void Form1_Load(object sender, EventArgs e)
        {
            //gerate the seats dyanamically for the seat booking
          var bbok=  s.CreateBoard(3,4);
         this.Controls.Add(bbok);
        }

        private void book_Click(object sender, EventArgs e)
        {
            //calling method and varify that if user selected row and colums or not?
            bool a;
            if (sr == null && selectedcol == null)
            { MessageBox.Show("please select row&&colum"); }
            else if (selectedcol == null)
            {
                MessageBox.Show("please select coloum");
            }
            else if (sr == null )
            { MessageBox.Show("please select coloum"); }
            else
            {
                a = s.book(sr, selectedcol, name.Text);
                if (a) { text.Text = name.Text + " book seat in " + sr + selectedcol; }
                label4.Text = s.GetAvilableSeatsNUmber();
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //getting the  values from listbox
            sr = listBox1.SelectedItem.ToString();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //getting the  values from listbox
             selectedcol = listBox2.SelectedItem.ToString();

        }

        private void cancel_Click(object sender, EventArgs e)
        {
            //calling method and varify that if user selected row and colums or not?
            bool a;
            if (sr == null && selectedcol == null)
            { MessageBox.Show("please select row&&colum"); }
            else if (selectedcol == null)
            {
                MessageBox.Show("please select coloum");
            }
            else if (sr == null)
            { MessageBox.Show("please select coloum"); }
            else
            {
                a = s.cancel(sr, selectedcol, name.Text);
                if (a) { text.Text = name.Text + "cancel seat in" + sr + selectedcol; }
                label4.Text = s.GetAvilableSeatsNUmber();
            }
            s.checkseatsforwait(name.Text,listBox3);
            int index = 0;
            for (int i = 0; i < 12; i++) { if (s.wait[i] == null) { index = i; break; } }
            for (int i = 0; i < index; i++) { listBox3.Items.Add(s.wait[i]); }
        }

        private void bookAllSeats_Click(object sender, EventArgs e)
        {
            //calling methods from seats class
            bool a;
                a = s.bookAllSeats(name.Text);
                if (a) { text.Text = name.Text + " booked all remaing seats "; }
                label4.Text = s.GetAvilableSeatsNUmber();
            
        }

        private void CancelAllSeats_Click(object sender, EventArgs e)
        {
            //calling methods from seats class
            bool a;
           
                a = s.CancelAllSeats(name.Text);
             
                label4.Text = s.GetAvilableSeatsNUmber();
            
            s.checkseatsforwait(name.Text,listBox3);
            int index = 0;
            for (int i = 0; i < 12; i++) { if (s.wait[i] == null) { index = i; break; } }
            for (int i = 0; i < index; i++) { listBox3.Items.Add(s.wait[i]); }
            if (a) { text.Text = name.Text + " cancel all seats "; label3.Text = s.GetwishlistSeatsNUmber(listBox3) + " on whish list"; }

        }

        private void addToWishList_Click(object sender, EventArgs e)
        {
            //calling methods from seats class
            s.waitlist( name.Text,listBox3);
                text.Text = name.Text + " in waiting list ";
              
                int index = 0;
                for (int i = 0; i < 12; i++) { if (s.wait[i] == null) { index = i;break; } }
                for(int i = 0; i < index; i++) { listBox3.Items.Add(s.wait[i]); }
            label3.Text = s.GetwishlistSeatsNUmber(listBox3) + " on whish list";


        }
    }
}