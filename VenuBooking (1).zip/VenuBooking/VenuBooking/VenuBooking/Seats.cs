﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VenuBooking
{
    using System;
    using System.Globalization;
    using System.Security.Cryptography;
    using System.Windows.Forms;
    using System.Xml.Linq;

    public class Seats
    {  // Set private global variables, to be used throughout the class
        private bool playerTurn;
        private string[,] boardArray;
        private TableLayoutPanel board;
        private int[,] seatsbook = new int[3, 4] { { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };
        private string[,] bookName = new string[3, 4];
        private string[,] seatsNumber = new string[3, 4] { { "A1", "A2", "A3", "A4" }, { "B1", "B2", "B3", "B4" }, { "C1", "C2", "C3", "C4" } };
        public string[] wait = new string[12];
       
        public TableLayoutPanel CreateBoard(int boardRows, int boardColumns)
        {
            //create the vanue booking seats using tablelayoutpanel and dynamically
            board = new TableLayoutPanel();
            board.Location = new Point(200, 100);
            board.RowCount = boardRows;
            board.ColumnCount = boardColumns;
            board.AutoSize = true;

            boardArray = new string[3, 4] { { "A1", "A2", "A3", "A4" }, { "B1", "B2", "B3", "B4" }, { "C1", "C2", "C3", "C4" } };
            System.Windows.Forms.ToolTip ToolTip1 = new System.Windows.Forms.ToolTip();

            for (int y = 0; y < boardArray.GetLength(0); y++)
            {
                for (int x = 0; x < boardColumns; x++)
                {
                    // Dynamically create buttons for each boardArray and at it to each one
                    var button = new Button();
                    button.Size = new Size(50, 50);
                    button.Font = new Font(FontFamily.GenericSansSerif, 8);
                    button.BackColor = Color.Green;
                    button.Text = boardArray[y, x];
                    button.Name = boardArray[y, x];
                    button.MouseHover += OnMouseEnterButton;
                    
                   
                        int[] buttonIndex = { x, y };
                    button.Tag = buttonIndex; // Add the button location to the button

                    board.Controls.Add(button); // Add each dynamically created button to the Controls (adds it to the form)
                }
            }
            return board; // We need to return the TableLayoutPanel to the form, so it can be added to the form
        }
        public bool book(string row, string col, string name)
        {
            //Method for the bboking seats
            bool a = false;
            string selectedItem = row.ToString() + col.ToString();
            int row_int = -1, col_int = -1;
            if (row == "A") { row_int = 0; } else if (row == "B") { row_int = 1; } else if (row == "C") { row_int = 2; } else { }
            col_int = int.Parse(col.ToString()) - 1;
            if (seatsbook[row_int, col_int] == 0 && name != "")
            {
                foreach (Control control in board.Controls)
                {
                    // Check if the control is a button
                    if (control is Button)
                    {
                        // Get the text of the button

                        string buttonText = control.Text;

                        // Compare the text of the button with the selected item from the ListBox
                        if (buttonText == selectedItem)
                        {
                            // Change the color of the button to red
                            control.BackColor = Color.Red;
                            a= true;

                            seatsbook[row_int, col_int] = 1;
                            bookName[row_int, col_int] = name;
                        }

                    }
                }
            }
            else if (seatsbook[row_int, col_int] == 1)
            {
                MessageBox.Show("seat alredy booked");
            }
            else if (seatsbook[row_int, col_int] == 2)
            {
                MessageBox.Show("seat alredy in someone wishlist");
            }
            else if (name == "")
            {
                MessageBox.Show("name should not be empty");
            }
            return a;

        }
        public bool cancel(string row, string col, string name)
        {
            //method for the cancle the seats
            bool a= false;
            string selectedItem = row.ToString() + col.ToString();
            int row_int = -1, col_int = -1;
            if (row == "A") { row_int = 0; } else if (row == "B") { row_int = 1; } else if (row == "C") { row_int = 2; } else { }
            col_int = int.Parse(col.ToString()) - 1;
            if (seatsbook[row_int, col_int] == 0)
            {
                MessageBox.Show("seat alredy empty");
            }
          
            else if (name == "")
            {
                MessageBox.Show("name should not be empty");
            }
            else if (seatsbook[row_int, col_int] == 1 && name != "")
            {
                if (bookName[row_int, col_int] == name)
                {
                    foreach (Control control in board.Controls)
                    {
                        // Check if the control is a button
                        if (control is Button)
                        {
                            // Get the text of the button
                            string buttonText = control.Text;

                            // Compare the text of the button with the selected item from the ListBox
                            if (buttonText == selectedItem)
                            {
                              
                                DialogResult dialogResult = MessageBox.Show("are you sure want to cancel seat?", "Some Title", MessageBoxButtons.YesNo);
                                if (dialogResult == DialogResult.Yes)
                                {
                                    control.BackColor = Color.Green;
                                    a = true;
                                    seatsbook[row_int, col_int] = 0;
                                    bookName[row_int, col_int] = "";
                                }
                                else if (dialogResult == DialogResult.No)
                                {
                                    MessageBox.Show("don,t worry your seat is safe!");
                                }
                               
                            }

                        }
                    }

                }
                
                else
                {
                    MessageBox.Show("name does not match please enter valid name");
                }
            }
            else if (seatsbook[row_int, col_int] == 2 && name != "")
            {
                if (bookName[row_int, col_int] == name)
                {
                    foreach (Control control in board.Controls)
                    {
                        // Check if the control is a button
                        if (control is Button)
                        {
                            // Get the text of the button
                            string buttonText = control.Text;

                            // Compare the text of the button with the selected item from the ListBox
                            if (buttonText == selectedItem)
                            {
                                // Change the color of the button to red
                                DialogResult dialogResult = MessageBox.Show("are you sure want to cancel seat?", "Some Title", MessageBoxButtons.YesNo);
                                if (dialogResult == DialogResult.Yes)
                                {
                                    a = true;
                                    control.BackColor = Color.Red;
                                    bookName[row_int, col_int] = "";
                                    seatsbook[row_int, col_int] = 0;
                                }
                                else if (dialogResult == DialogResult.No)
                                {
                                    MessageBox.Show("don,t worry your seat is safe!");
                                }
                                
                            }

                        }
                    }

                }
            }
            return a;
        }
        public bool bookAllSeats(string name)
        {
            //method for the book all seats
            bool a = false; 
            if (name != "")
            {
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        if (seatsbook[i, j] == 0)
                        {

                            string selectedItem = seatsNumber[i, j];


                            foreach (Control control in board.Controls)
                            {
                                // Check if the control is a button
                                if (control is Button)
                                {
                                    // Get the text of the button
                                    string buttonText = control.Text;

                                    // Compare the text of the button with the selected item from the ListBox
                                    if (buttonText == selectedItem)
                                    {
                                        // Change the color of the button to red
                                        control.BackColor = Color.Red;

                                        seatsbook[i, j] = 1;
                                        bookName[i, j] = name;
                                        a= true;
                                    }

                                }
                            }


                        }

                    }
                }
            }
            else
            {
                MessageBox.Show("name should not be empty");
            }

            return a;
        }
        public bool CancelAllSeats(string name)
        {
            //method for the cancle all seats
            bool a=false;
            if (name != "")
            {
                DialogResult dialogResult = MessageBox.Show("are you sure want to cancel all seat?", "Some Title", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        for (int j = 0; j < 4; j++)
                        {
                            if (seatsbook[i, j] == 1)
                            {

                                string selectedItem = seatsNumber[i, j];


                                foreach (Control control in board.Controls)
                                {
                                    // Check if the control is a button
                                    if (control is Button)
                                    {
                                        // Get the text of the button
                                        string buttonText = control.Text;

                                        // Compare the text of the button with the selected item from the ListBox
                                        if (buttonText == selectedItem)
                                        {
                                            // Change the color of the button to red
                                            control.BackColor = Color.Green;
                                            a = true;
                                            seatsbook[i, j] = 0;
                                            bookName[i, j] = "";

                                        }

                                    }
                                }


                            }

                        }
                    }

                }
                else if (dialogResult == DialogResult.No)
                {
                    MessageBox.Show("don,t worry your seats are safe!");
                }
               
            }
            return a;
        }
        public string GetAvilableSeatsNUmber()
        {
            //method for get avilable seats number for display 
            int count = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (seatsbook[i, j] == 0)
                    {
                        count++;
                    }
                }


            }
            return (Convert.ToString(count));
        }
        public string GetwishlistSeatsNUmber(ListBox l)
        {
            //getting the wishlist seat number how many customer are waitting
            int a;
            a=l.Items.Count;
            return Convert.ToString(a);
        }
        public  void waitlist( string name,ListBox l)
        {
            //method for the waitlist 
            bool full = true;
            for(int i=0;i<3; i++)
            { 
                for(int j=0;j<4;j++)
                {
                    if (seatsbook[i, j] == 0)
                    {
                        full = false;
                        break;
                    }
                }
            }
            if (full)
            {
               l.Items.Add(name);
            }
            else
            {
                MessageBox.Show("there is any seat which is empty");
            }
          
        }
        static string[] RemoveAt(string[] arr, int index)
        {
            //method  for the cancle all seats
            string[] newArr = new string[arr.Length - 1];
            int counter = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (i != index)
                {
                    newArr[counter] = arr[i];
                    counter++;
                }
            }
            return newArr;
        }
    
    public void checkseatsforwait(string namme,ListBox l)
        {
            //method for check seats for wait list
            
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (seatsbook[i, j] == 0)
                    {
                        string s = ""; if (i == 0) { s = "A"; }else if(i == 1) { s = "B"; } else { s = "C"; }
                        j = j+1 ;
                        string selectedItem = s+Convert.ToString(j);
                        if (l.Items.Count > 0)
                        {

                            foreach (Control control in board.Controls)
                            {
                                // Check if the control is a button
                                if (control is Button)
                                {
                                    // Get the text of the button
                                    string buttonText = control.Text;

                                    // Compare the text of the button with the selected item from the ListBox
                                    if (buttonText == selectedItem)
                                    {
                                        // Change the color of the button to red
                                        j = j - 1;
                                        control.BackColor = Color.Red;

                                        seatsbook[i, j] = 1;
                                        bookName[i, j] =Convert.ToString( l.Items[0]);
                                        
                                    }

                                }
                            }
                          /*  book(s, Convert.ToString(j), namme);*/
                            l.Items.RemoveAt(0);
                        }

                    }
                }
            }
        }

        
        public string countwaitlist()
        {
            //method for counting the waitlist numbers
            int count = 0;
            for (int i = 0; i < 12; i++)
            {
             
                    if (wait[i]!=null)
                    {
                        count++;
                    }
                


            }
            return (Convert.ToString(count));
        }
        private int status(int row,int col)
        {
            //method for status for sets 0=empty,1=booked,2=waitlist
            int status = 0;
            if (seatsbook[row, col] == 0) { status= 0; }
            if (seatsbook[row, col] == 1) { status= 1; }
            if (seatsbook[row, col] == 2) { status= 2; }
            return status;

        }
        ToolTip t1 = new ToolTip();
        private void OnMouseEnterButton(object sender, EventArgs e)
        {
            //method for mouse hover for displaying seats status
            Button? b = (Button)sender;
            string s = b.Text;
            string status="";
            int row_int = 0, col_int = 0;
            if (s[0] == 'A') { row_int = 0; } else if (s[0] == 'B') { row_int = 1; } else if (s[0] == 'C') { row_int = 2; } else { }
            if (s[1] == '1') { col_int = 0; } else if (s[1] == '2') { col_int = 1; } else if (s[1] == '3') { col_int = 2; } else if (s[1] == '4') { col_int = 3; } else { }
            if (seatsbook[row_int, col_int] == 0)
            {
                status = "AVAILABLE";
            }
            else if (seatsbook[row_int, col_int] == 1)
            {
                status = bookName[row_int,col_int]; 
            }
            else if (seatsbook[row_int,col_int] == 2)
            {
                status = "booked and 1 waiting";
            }
            else
            {
                status = "";
            }
          
            t1.Show(status, b);
            status =string.Empty;
        }
    }
}
